package com.marcelo.examen2perros




//private fun crearRetrofit(): ProveedorServicios {
//        val url = "http://xusa.iesdoctorbalmis.info/animales22/"
//       // val url = "http://10.0.2.2/animales22/"
//        val gson = GsonBuilder()
//            .setLenient()
//            .create()
//        val retrofit: Retrofit = Retrofit.Builder()
//            .baseUrl(url)
//            .addConverterFactory(GsonConverterFactory.create(gson))
//            .build()
//        return retrofit.create(ProveedorServicios::class.java)
//    }