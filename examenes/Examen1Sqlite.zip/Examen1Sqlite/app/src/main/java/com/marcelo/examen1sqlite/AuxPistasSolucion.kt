package com.marcelo.examen1sqlite

class AuxPistasSolucion(
    val pistauno: String,
    val pistados: String,
    val pistatres: String,
    val solucion: String,
    var numeroMayorPistaUsada:Int = 0
) {


}